/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FrameTest$1
/*    */   implements Runnable
/*    */ {
/*    */   FrameTest$1(FrameTest paramFrameTest) {}
/*    */   
/*    */   public void run()
/*    */   {
/*    */     for (;;)
/*    */     {
/*    */       try
/*    */       {
/* 74 */         Thread.sleep(100L);
/*    */       }
/*    */       catch (InterruptedException e) {
/* 77 */         e.printStackTrace();
/*    */       }
/* 79 */       this.this$0.setXY();
/*    */     }
/*    */   }
/*    */ }


/* Location:              A:\课程学习\课件\大二课件\小白的程序猿&射鸡狮之路\CodeRain.jar!\FrameTest$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */